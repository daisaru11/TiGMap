module.exports = "AIzaSyBS8WZZLsZV1gQ_ICfwKz93Ws-66RDwDMQ";
